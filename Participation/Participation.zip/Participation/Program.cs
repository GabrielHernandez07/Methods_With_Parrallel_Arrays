﻿using System;
using System.Collections.Generic;

namespace Participation
{
    class Program
    {
        static void Main(string[] args)
        {
            List<List<double>> grades = new List<List<double>>();
            grades.Add(new List<double>());
            grades.Add(new List<double>());
            grades.Add(new List<double>());
            grades.Add(new List<double>());
            grades.Add(new List<double>());

            grades[0].Add(75.5);
            grades[0].Add(70);
            grades[0].Add(72);

            grades[1].Add(80);
            grades[1].Add(83);
            grades[1].Add(86);

            grades[2].Add(90);
            grades[2].Add(95);
            grades[2].Add(99);

            grades[3].Add(60);
            grades[3].Add(66);
            grades[3].Add(70);

            grades[4].Add(90);
            grades[4].Add(80);
            grades[4].Add(60);

            double sum = 0;
            double average = 0;
            for (int i = 0; i < grades.Count; i++)
            {
                for (int x = 0; x < grades[x].Count; i++)
                {
                    sum = grades[x][x] + sum;
                    average = sum / grades[x].Count;
                }
                Console.WriteLine(grades[i].Count);
                Console.WriteLine(average);
            }
        }
        static void StudentInformation(string[] studentName, int[] studentID, List<List<double>> grades)
        {
            studentName = new string[5];
            studentName[0] = "Jimmy John";
            studentName[1] = "Kyle Walker";
            studentName[2] = "Gabriel Jesus";
            studentName[3] = "Phil Foden";
            studentName[4] = "Kevin Debruyne";

            studentID = new int[5];
            studentID[0] = 12345;
            studentID[1] = 54321;
            studentID[2] = 45678;
            studentID[3] = 56789;
            studentID[4] = 00001;

            grades = new List<List<double>>();
            grades.Add(new List<double>());
            grades.Add(new List<double>());
            grades.Add(new List<double>());
            grades.Add(new List<double>());
            grades.Add(new List<double>());

            grades[0].Add(75.5);
            grades[0].Add(70);
            grades[0].Add(72);

            grades[1].Add(80);
            grades[1].Add(83);
            grades[1].Add(86);

            grades[2].Add(90);
            grades[2].Add(95);
            grades[2].Add(99);

            grades[3].Add(60);
            grades[3].Add(66);
            grades[3].Add(70);

            grades[4].Add(90);
            grades[4].Add(80);
            grades[4].Add(60);

            double sum = 0;
            double average = 0;
            for (int i = 0; i < grades.Count; i++)
            {
                for (int x = 0; x < grades[x].Count; i++)
                {
                    sum = grades[x][x] + sum;
                    average = sum / grades[x].Count;
                }
                Console.WriteLine(grades[i].Count);
                Console.WriteLine(average);
            }

        }
    }
}
